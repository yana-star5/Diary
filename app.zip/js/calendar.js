/* Календарь и выбор дат */
const Calendar = (() => {
  const MONTHS = ['Январь','Февраль','Март','Апрель','Май','Июнь','Июль','Август','Сентябрь','Октябрь','Ноябрь','Декабрь'];
  let year, month, selected;
  let els = {};

  function init() {
    els = {
      title: document.getElementById('cal-title'),
      grid: document.getElementById('cal-grid'),
      dayTitle: document.getElementById('cal-day-title'),
      dayMood: document.getElementById('cal-day-mood'),
      list: document.getElementById('cal-list')
    };
    document.getElementById('cal-prev').addEventListener('click', () => shift(-1));
    document.getElementById('cal-next').addEventListener('click', () => shift(1));
    els.grid.addEventListener('click', e => {
      const btn = e.target.closest('.day[data-date]');
      if (!btn) return;
      selected = btn.dataset.date;
      render();
    });
  }

  function shift(delta) {
    month += delta;
    if (month < 0) { month = 11; year--; }
    if (month > 11) { month = 0; year++; }
    render();
  }

  /* По умолчанию — текущий месяц и текущая дата */
  function open() {
    const now = new Date();
    year = now.getFullYear();
    month = now.getMonth();
    selected = Store.dateKey(now);
    render();
  }

  function render() {
    els.title.textContent = `${MONTHS[month]} ${year}`;
    els.grid.replaceChildren();
    const offset = (new Date(year, month, 1).getDay() + 6) % 7; // неделя с понедельника
    const days = new Date(year, month + 1, 0).getDate();
    const today = Store.dateKey();
    const frag = document.createDocumentFragment();

    for (let i = 0; i < offset; i++) {
      const b = document.createElement('div');
      b.className = 'day blank';
      frag.append(b);
    }
    for (let d = 1; d <= days; d++) {
      const key = Store.dateKey(new Date(year, month, d));
      const btn = document.createElement('button');
      btn.type = 'button';
      btn.dataset.date = key;
      btn.textContent = d;
      let cls = 'day';
      const mood = Store.getMood(key);
      if (mood) cls += ' m' + mood;
      if (Store.hasEntries(key)) cls += ' has';
      if (key === today) cls += ' today';
      if (key === selected) cls += ' sel';
      btn.className = cls;
      frag.append(btn);
    }
    els.grid.append(frag);
    renderDetail();
  }

  function renderDetail() {
    els.dayTitle.textContent = Entries.formatDate(selected);
    const mood = Store.getMood(selected);
    els.dayMood.replaceChildren();
    const dot = document.createElement('i');
    if (mood) dot.className = 'm' + mood;
    const label = document.createElement('span');
    label.textContent = mood ? 'Настроение: ' + Store.MOODS[mood].toLowerCase() : 'Настроение не отмечено';
    els.dayMood.append(dot, label);
    Entries.renderList(els.list, Store.getEntries(selected), 'В этот день записей нет', render);
  }

  return { init, open };
})();
