/* Создание и отображение записей */
const Entries = (() => {
  const MONTHS_GEN = ['января','февраля','марта','апреля','мая','июня','июля','августа','сентября','октября','ноября','декабря'];
  const WEEKDAYS = ['воскресенье','понедельник','вторник','среда','четверг','пятница','суббота'];

  function formatDate(key) {
    const d = Store.parseKey(key);
    const year = d.getFullYear() === new Date().getFullYear() ? '' : ' ' + d.getFullYear();
    return `${d.getDate()} ${MONTHS_GEN[d.getMonth()]}${year}, ${WEEKDAYS[d.getDay()]}`;
  }

  /* Диалог подтверждения удаления (свой, без alert/confirm — они не везде работают в WebView) */
  function confirmDelete(entry, onDone) {
    const modal = document.getElementById('confirm');
    const yes = document.getElementById('confirm-yes');
    const no = document.getElementById('confirm-no');
    const close = () => { modal.hidden = true; yes.onclick = no.onclick = modal.onclick = null; };
    modal.hidden = false;
    no.onclick = close;
    modal.onclick = e => { if (e.target === modal) close(); };
    yes.onclick = async () => {
      yes.disabled = true;
      try {
        await Store.deleteEntry(entry.id);
        close();
        onDone();
      } catch (e) {
        close();
        alert('Не удалось удалить запись.');
      } finally {
        yes.disabled = false;
      }
    };
  }

  function card(entry, onChange) {
    const el = document.createElement('article');
    el.className = 'card entry';
    const p = document.createElement('p');
    p.textContent = entry.text;
    const foot = document.createElement('div');
    foot.className = 'entry-foot';
    const t = document.createElement('time');
    t.textContent = entry.time;
    const del = document.createElement('button');
    del.type = 'button';
    del.className = 'del-btn';
    del.setAttribute('aria-label', 'Удалить запись');
    del.innerHTML = '<svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 7h14M10 7V4.5h4V7M7 7l.8 12.5h8.4L17 7M10.5 11v5M13.5 11v5"/></svg>';
    del.addEventListener('click', () => confirmDelete(entry, onChange));
    foot.append(t, del);
    el.append(p, foot);
    return el;
  }

  function renderList(container, list, emptyText, onChange) {
    container.replaceChildren();
    if (!list.length) {
      const e = document.createElement('div');
      e.className = 'empty';
      e.textContent = emptyText;
      container.append(e);
      return;
    }
    list.forEach(entry => container.append(card(entry, onChange)));
  }

  /* Записи текущего дня: новые — сверху, сразу под полем ввода */
  function renderToday(container, onChange) {
    const list = Store.getEntries(Store.dateKey()).reverse();
    container.replaceChildren();
    list.forEach(entry => container.append(card(entry, onChange)));
  }

  function initComposer(input, button, onSaved) {
    button.addEventListener('click', async () => {
      const text = input.value.trim();
      if (!text) { input.focus(); return; }
      button.disabled = true;
      try {
        await Store.addEntry(text);
        input.value = '';
        onSaved();
      } catch (e) {
        alert('Не удалось сохранить запись. Текст остался в поле, попробуйте ещё раз.');
      } finally {
        button.disabled = false;
      }
    });
  }

  return { formatDate, renderList, renderToday, initComposer };
})();
