/* Локальное хранение: IndexedDB, при её недоступности — localStorage.
   Все данные держатся в кэше в памяти; каждая запись сразу пишется на диск. */
const Store = (() => {
  const DB_NAME = 'gratitude-diary', DB_VERSION = 1;
  const LS_ENTRIES = 'gd_entries', LS_MOODS = 'gd_moods';
  const MOODS = { 1: 'Не очень', 2: 'Обычный', 3: 'Хороший' };
  let db = null;
  const cache = { entries: [], moods: {} };

  const pad = n => String(n).padStart(2, '0');
  const dateKey = (d = new Date()) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const timeKey = (d = new Date()) => `${pad(d.getHours())}:${pad(d.getMinutes())}`;
  const parseKey = key => { const [y, m, d] = key.split('-').map(Number); return new Date(y, m - 1, d); };
  const newId = () => (window.crypto && crypto.randomUUID) ? crypto.randomUUID()
    : Date.now().toString(36) + Math.random().toString(36).slice(2, 10);

  function openDb() {
    return new Promise((resolve, reject) => {
      if (!window.indexedDB) return reject(new Error('IndexedDB недоступна'));
      const req = indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = () => {
        const d = req.result;
        if (!d.objectStoreNames.contains('entries')) d.createObjectStore('entries', { keyPath: 'id' }).createIndex('date', 'date');
        if (!d.objectStoreNames.contains('moods')) d.createObjectStore('moods', { keyPath: 'date' });
      };
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => reject(req.error);
      req.onblocked = () => reject(new Error('База заблокирована'));
    });
  }
  const idbAll = name => new Promise((res, rej) => {
    const r = db.transaction(name).objectStore(name).getAll();
    r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error);
  });
  const idbPut = (name, obj) => new Promise((res, rej) => {
    const t = db.transaction(name, 'readwrite');
    t.objectStore(name).put(obj);
    t.oncomplete = () => res(); t.onerror = () => rej(t.error); t.onabort = () => rej(t.error);
  });
  const idbDelete = (name, key) => new Promise((res, rej) => {
    const t = db.transaction(name, 'readwrite');
    t.objectStore(name).delete(key);
    t.oncomplete = () => res(); t.onerror = () => rej(t.error); t.onabort = () => rej(t.error);
  });
  const lsRead = (key, fallback) => { try { return JSON.parse(localStorage.getItem(key)) || fallback; } catch (e) { return fallback; } };

  async function init() {
    try {
      db = await openDb();
      cache.entries = await idbAll('entries');
      (await idbAll('moods')).forEach(m => { cache.moods[m.date] = m.level; });
      if (navigator.storage && navigator.storage.persist) navigator.storage.persist().catch(() => {});
    } catch (e) {
      db = null; // запасной вариант
      cache.entries = lsRead(LS_ENTRIES, []);
      cache.moods = lsRead(LS_MOODS, {});
    }
  }

  const byTime = (a, b) => (a.createdAt < b.createdAt ? -1 : a.createdAt > b.createdAt ? 1 : 0);

  async function addEntry(text) {
    const now = new Date();
    const entry = { id: newId(), text, createdAt: now.toISOString(), date: dateKey(now), time: timeKey(now) };
    if (db) await idbPut('entries', entry);
    else { localStorage.setItem(LS_ENTRIES, JSON.stringify(cache.entries.concat(entry))); }
    cache.entries.push(entry);
    return entry;
  }

  async function setMood(date, level) {
    if (db) await idbPut('moods', { date, level });
    else { localStorage.setItem(LS_MOODS, JSON.stringify(Object.assign({}, cache.moods, { [date]: level }))); }
    cache.moods[date] = level;
  }

  async function deleteEntry(id) {
    const rest = cache.entries.filter(e => e.id !== id);
    if (db) await idbDelete('entries', id);
    else localStorage.setItem(LS_ENTRIES, JSON.stringify(rest));
    cache.entries = rest;
  }

  async function clearMood(date) {
    if (db) await idbDelete('moods', date);
    else {
      const rest = Object.assign({}, cache.moods);
      delete rest[date];
      localStorage.setItem(LS_MOODS, JSON.stringify(rest));
    }
    delete cache.moods[date];
  }

  return {
    MOODS, dateKey, parseKey, init, addEntry, setMood, deleteEntry, clearMood,
    getMood: date => cache.moods[date] || 0,
    getEntries: date => cache.entries.filter(e => e.date === date).sort(byTime),
    getAllEntries: () => cache.entries.slice().sort(byTime),
    hasEntries: date => cache.entries.some(e => e.date === date)
  };
})();
