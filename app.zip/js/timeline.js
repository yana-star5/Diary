/* Общая лента: даты от новых к старым, внутри даты — по порядку создания */
const Timeline = (() => {
  function render() {
    const root = document.getElementById('timeline-list');
    root.replaceChildren();
    const all = Store.getAllEntries();
    if (!all.length) {
      const e = document.createElement('div');
      e.className = 'empty';
      e.textContent = 'Записей пока нет';
      root.append(e);
      return;
    }
    const groups = new Map();
    all.forEach(entry => {
      if (!groups.has(entry.date)) groups.set(entry.date, []);
      groups.get(entry.date).push(entry);
    });
    const frag = document.createDocumentFragment();
    [...groups.keys()].sort().reverse().forEach(date => {
      const group = document.createElement('section');
      group.className = 'tl-group';
      const h = document.createElement('h2');
      h.textContent = Entries.formatDate(date);
      const box = document.createElement('div');
      box.className = 'tl-box';
      groups.get(date).forEach(entry => {
        const item = document.createElement('div');
        item.className = 'tl-item';
        const p = document.createElement('p');
        p.textContent = entry.text;
        item.append(p);
        box.append(item);
      });
      group.append(h, box);
      frag.append(group);
    });
    root.append(frag);
  }
  return { render };
})();
