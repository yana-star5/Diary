/* Запуск, навигация между тремя экранами, настроение дня */
(function () {
  const screens = {
    home: document.getElementById('screen-home'),
    calendar: document.getElementById('screen-calendar'),
    timeline: document.getElementById('screen-timeline')
  };
  const todayList = document.getElementById('today-list');
  const moodButtons = document.querySelectorAll('#mood-row .mood');

  const current = () => {
    const h = location.hash.replace('#', '');
    return screens[h] ? h : 'home';
  };

  function renderMood() {
    const level = Store.getMood(Store.dateKey());
    moodButtons.forEach(b => b.setAttribute('aria-pressed', String(Number(b.dataset.mood) === level)));
  }
  function renderHome() {
    Entries.renderToday(todayList, renderHome);
    renderMood();
  }

  function show(name) {
    Object.keys(screens).forEach(k => { screens[k].hidden = k !== name; });
    window.scrollTo(0, 0);
    if (name === 'home') renderHome();
    if (name === 'calendar') Calendar.open();
    if (name === 'timeline') Timeline.render();
  }

  function go(name) {
    try { history.pushState({ app: 1 }, '', '#' + name); } catch (e) {}
    show(name);
  }
  function back() {
    if (history.state && history.state.app) { history.back(); return; }
    try { history.replaceState(null, '', location.pathname + location.search); } catch (e) {}
    show('home');
  }

  async function start() {
    try {
      await Store.init();
    } catch (e) {
      const err = document.createElement('div');
      err.className = 'error';
      err.textContent = 'Не удалось открыть хранилище данных. Перезапустите приложение.';
      document.querySelector('.app').prepend(err);
      return;
    }
    Calendar.init();
    Transfer.init();
    Entries.initComposer(document.getElementById('entry-input'), document.getElementById('btn-save'), renderHome);

    document.getElementById('btn-calendar').addEventListener('click', () => go('calendar'));
    document.getElementById('btn-timeline').addEventListener('click', () => go('timeline'));
    document.querySelectorAll('.back').forEach(b => b.addEventListener('click', back));
    window.addEventListener('popstate', () => show(current()));

    moodButtons.forEach(b => b.addEventListener('click', async () => {
      try {
        const date = Store.dateKey();
        const level = Number(b.dataset.mood);
        // повторное нажатие на выбранное настроение снимает отметку
        if (Store.getMood(date) === level) await Store.clearMood(date);
        else await Store.setMood(date, level);
        renderMood();
      } catch (e) {
        alert('Не удалось сохранить настроение.');
      }
    }));

    // Если приложение пролежало в фоне до новой даты — обновить главный экран
    document.addEventListener('visibilitychange', () => {
      if (!document.hidden && current() === 'home') renderHome();
    });

    show(current());
  }

  start();
})();
