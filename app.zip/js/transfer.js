/* Выгрузка всех записей в txt и загрузка обратно (на другом устройстве) */
const Transfer = (() => {
  const MARK = 'ДНЕВНИК БЛАГОДАРНОСТИ';
  const pad = n => String(n).padStart(2, '0');

  /* Файл читается глазами и разбирается обратно:
     === 2026-11-19 | ...   — начало дня
     Настроение: Хороший    — настроение дня
     [09:15] текст          — запись; продолжение строк начинается с двух пробелов */
  function buildText() {
    const entries = Store.getAllEntries();
    const moods = Store.getMoods();
    const days = new Set(entries.map(e => e.date));
    Object.keys(moods).forEach(d => days.add(d));
    const now = new Date();
    const out = [
      MARK,
      'Файл можно загрузить обратно в приложение. Даты, строки «Настроение» и время в скобках лучше не менять.',
      `Выгрузка: ${pad(now.getDate())}.${pad(now.getMonth() + 1)}.${now.getFullYear()} ${pad(now.getHours())}:${pad(now.getMinutes())}`,
      ''
    ];
    [...days].sort().forEach(date => {
      out.push(`=== ${date} | ${Entries.formatDate(date)}`);
      const mood = Store.getMood(date);
      if (mood) out.push(`Настроение: ${Store.MOODS[mood]}`);
      Store.getEntries(date).forEach(e => {
        const lines = e.text.split(/\r?\n/);
        out.push(`[${e.time}] ${lines[0]}`);
        lines.slice(1).forEach(l => out.push('  ' + l));
      });
      out.push('');
    });
    return out.join('\n');
  }

  function parseText(raw) {
    const nameToLevel = {};
    Object.keys(Store.MOODS).forEach(k => { nameToLevel[Store.MOODS[k]] = Number(k); });
    const entries = [], moods = {};
    let date = null, cur = null;
    const flush = () => {
      if (cur) {
        cur.text = cur.text.replace(/\s+$/, '');
        if (cur.text) entries.push(cur);
        cur = null;
      }
    };
    raw.replace(/^\uFEFF/, '').split(/\r?\n/).forEach(line => {
      let m;
      if ((m = line.match(/^=== (\d{4})-(\d{2})-(\d{2})/))) {
        flush();
        date = (+m[2] >= 1 && +m[2] <= 12 && +m[3] >= 1 && +m[3] <= 31) ? `${m[1]}-${m[2]}-${m[3]}` : null;
      } else if (date && (m = line.match(/^Настроение: (.+)$/))) {
        flush();
        const level = nameToLevel[m[1].trim()];
        if (level) moods[date] = level;
      } else if (date && (m = line.match(/^\[(\d{2}):(\d{2})\] ?(.*)$/))) {
        flush();
        if (+m[1] < 24 && +m[2] < 60) cur = { date, time: `${m[1]}:${m[2]}`, text: m[3] };
      } else if (cur && line.startsWith('  ')) {
        cur.text += '\n' + line.slice(2);
      }
    });
    flush();
    return { entries, moods };
  }

  async function exportFile() {
    const text = buildText();
    const name = `dnevnik-blagodarnosti-${Store.dateKey()}.txt`;
    const cap = window.Capacitor;
    const plugins = cap && cap.Plugins;
    const native = cap && cap.isNativePlatform && cap.isNativePlatform();
    if (native && plugins && plugins.Filesystem && plugins.Share) {
      // В установленном приложении: файл во временную папку и системное меню «Поделиться»
      const res = await plugins.Filesystem.writeFile({ path: name, data: text, directory: 'CACHE', encoding: 'utf8' });
      await plugins.Share.share({ title: 'Дневник благодарности', dialogTitle: 'Сохранить файл', files: [res.uri] });
      return;
    }
    // В браузере — обычное скачивание
    const url = URL.createObjectURL(new Blob([text], { type: 'text/plain;charset=utf-8' }));
    const a = document.createElement('a');
    a.href = url; a.download = name;
    document.body.append(a); a.click(); a.remove();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  const readFile = file => new Promise((res, rej) => {
    const r = new FileReader();
    r.onload = () => res(String(r.result));
    r.onerror = () => rej(r.error);
    r.readAsText(file, 'utf-8');
  });

  const info = (text) => Entries.dialog(text, [{ label: 'Понятно', primary: true }]);

  async function run(data, mode) {
    try {
      const r = await Store.importData(data, mode);
      Timeline.render();
      info(mode === 'replace'
        ? `Данные заменены. Записей: ${r.entries}, дней с настроением: ${r.moods}.`
        : `Добавлено записей: ${r.entries}. Новых отметок настроения: ${r.moods}.`);
    } catch (e) {
      info('Не удалось загрузить данные. Ничего не изменилось.');
    }
  }

  async function onFile(e) {
    const file = e.target.files && e.target.files[0];
    e.target.value = '';
    if (!file) return;
    let data;
    try { data = parseText(await readFile(file)); }
    catch (err) { info('Не удалось прочитать файл.'); return; }
    const days = Object.keys(data.moods).length;
    if (!data.entries.length && !days) {
      info('В этом файле не нашлось записей дневника. Загрузите файл, который был выгружен из приложения.');
      return;
    }
    Entries.dialog(`В файле: записей — ${data.entries.length}, дней с настроением — ${days}.\n\nЧто сделать?`, [
      { label: 'Добавить к имеющимся', primary: true, onClick: () => run(data, 'merge') },
      { label: 'Заменить всё', onClick: () => Entries.dialog(
          'Все текущие записи и настроения будут удалены и заменены данными из файла. Вернуть их будет нельзя.',
          [{ label: 'Отмена' }, { label: 'Заменить всё', primary: true, onClick: () => run(data, 'replace') }]) },
      { label: 'Отмена' }
    ]);
  }

  function init() {
    document.getElementById('btn-export').addEventListener('click', async () => {
      try { await exportFile(); }
      catch (e) {
        if (!/cancel/i.test(String((e && e.message) || e))) info('Не удалось выгрузить файл.');
      }
    });
    const input = document.getElementById('import-file');
    document.getElementById('btn-import').addEventListener('click', () => input.click());
    input.addEventListener('change', onFile);
  }

  return { init, buildText, parseText };
})();
